# Enhanced Master Vault

Enhanced Master Vault is a chrome extension for enhancing the experience of the KeyForge Master Vault website with additional data such as SAS/AERC ratings/scores provided by [Decks of KeyForge](https://decksofkeyforge.com).

## How To Use

Once installed, simply login to your Asmodee account and navigate to the KeyForge Master Vault site.

## How To Install

Download the code

Open chrome -> right-click extension bar -> "Manage extensions"

Toggle Developer Mode on

Click "Load unpacked"

### Disclaimer

This code is provided "as is" and should not be considered fit for any purpose. Use at your own risk. Using this code may result in the loss of data, closure of accounts, bans, or otherwise have undesired effects.